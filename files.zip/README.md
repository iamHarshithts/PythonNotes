# Satellite AQI Monitor - React Version

A React-based air quality monitoring application with interactive maps and real-time pollution data visualization.

## Features

- 🌍 **Real-time Air Quality Data**: View current AQI and pollutant levels
- 🗺️ **Interactive Maps**: Powered by Leaflet.js
- 🔥 **Heatmap Visualization**: See pollution intensity zones
- 📊 **3-Day Forecast**: Predicted AQI based on dispersion models
- 📱 **Responsive Design**: Works on desktop, tablet, and mobile

## Installation

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start the development server:**
   ```bash
   npm start
   ```

The app will open at `http://localhost:3000`

## Usage

### Basic Setup

Import and use the component in your app:

```jsx
import React from 'react';
import SatelliteAQIMonitor from './SatelliteAQIMonitor';

function App() {
  return (
    <div className="App">
      <SatelliteAQIMonitor />
    </div>
  );
}

export default App;
```

### Backend API

The component expects a backend endpoint at `/get-pollution` that accepts `lat` and `lon` query parameters:

```
GET /get-pollution?lat=28.6139&lon=77.2090
```

**Expected Response Format:**
```json
{
  "current": {
    "aqi": 150,
    "label": "Unhealthy for Sensitive Groups",
    "color": "#ff9800",
    "components": {
      "pm2_5": 55.3,
      "pm10": 87.2,
      "no2": 42.1,
      "so2": 15.6,
      "co": 234.5,
      "o3": 45.2
    }
  },
  "forecast": [
    {
      "dt": 1707696000,
      "aqi": 145,
      "aqi_label": "Unhealthy for Sensitive Groups",
      "aqi_color": "#ff9800",
      "components": {
        "pm2_5": 52.1
      }
    }
  ]
}
```

## Adding Responsive Styles

For production use, consider adding media queries using one of these approaches:

### Option 1: CSS Module
Create `SatelliteAQIMonitor.module.css`:

```css
@media (max-width: 768px) {
  .gridSplit {
    grid-template-columns: 1fr !important;
  }
  .controls {
    flex-direction: column;
  }
}
```

### Option 2: Styled Components
```bash
npm install styled-components
```

### Option 3: Tailwind CSS
```bash
npm install -D tailwindcss
```

## Dependencies

- **React** (^18.2.0): UI framework
- **Leaflet** (^1.9.4): Interactive maps
- **Leaflet.heat** (^0.2.0): Heatmap layer

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

MIT
