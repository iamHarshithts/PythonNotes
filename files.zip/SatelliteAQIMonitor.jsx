import React, { useState, useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet.heat';

const SatelliteAQIMonitor = () => {
  const [lat, setLat] = useState('28.6139');
  const [lon, setLon] = useState('77.2090');
  const [activeTab, setActiveTab] = useState('current');
  const [loading, setLoading] = useState(false);
  const [currentData, setCurrentData] = useState({
    aqi: '--',
    label: 'Enter Coordinates',
    color: '#eee',
    components: {
      pm2_5: '-',
      pm10: '-',
      no2: '-',
      so2: '-',
      co: '-',
      o3: '-'
    }
  });
  const [forecastData, setForecastData] = useState([]);

  const mapRef = useRef(null);
  const heatMapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const heatMapInstanceRef = useRef(null);
  const markerRef = useRef(null);
  const heatLayerRef = useRef(null);

  // Initialize maps
  useEffect(() => {
    if (!mapInstanceRef.current && mapRef.current) {
      mapInstanceRef.current = L.map(mapRef.current).setView([20.5937, 78.9629], 5);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap'
      }).addTo(mapInstanceRef.current);
    }

    if (!heatMapInstanceRef.current && heatMapRef.current) {
      heatMapInstanceRef.current = L.map(heatMapRef.current).setView([20.5937, 78.9629], 5);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(heatMapInstanceRef.current);
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
      if (heatMapInstanceRef.current) {
        heatMapInstanceRef.current.remove();
        heatMapInstanceRef.current = null;
      }
    };
  }, []);

  // Fix map rendering when switching tabs
  useEffect(() => {
    setTimeout(() => {
      if (mapInstanceRef.current) mapInstanceRef.current.invalidateSize();
      if (heatMapInstanceRef.current) heatMapInstanceRef.current.invalidateSize();
    }, 150);
  }, [activeTab]);

  const fetchData = async () => {
    if (!lat || !lon) {
      alert('Please enter valid coordinates');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(`/get-pollution?lat=${lat}&lon=${lon}`);
      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      // Update current data
      const cur = data.current;
      setCurrentData(cur);

      // Update map
      if (mapInstanceRef.current) {
        mapInstanceRef.current.setView([lat, lon], 13);
        if (markerRef.current) {
          mapInstanceRef.current.removeLayer(markerRef.current);
        }
        markerRef.current = L.marker([lat, lon])
          .addTo(mapInstanceRef.current)
          .bindPopup(`<b>AQI: ${cur.aqi}</b><br>${cur.label}`)
          .openPopup();
      }

      // Update forecast
      if (data.forecast && data.forecast.length > 0) {
        setForecastData(data.forecast);
      } else {
        setForecastData([]);
      }

      // Update heatmap
      if (heatMapInstanceRef.current) {
        heatMapInstanceRef.current.setView([lat, lon], 12);
        if (heatLayerRef.current) {
          heatMapInstanceRef.current.removeLayer(heatLayerRef.current);
        }

        // Generate heatmap points
        let heatPoints = [[parseFloat(lat), parseFloat(lon), 1.0]];
        for (let i = 0; i < 15; i++) {
          let rLat = parseFloat(lat) + (Math.random() - 0.5) * 0.04;
          let rLon = parseFloat(lon) + (Math.random() - 0.5) * 0.04;
          heatPoints.push([rLat, rLon, Math.random() * 0.8]);
        }

        heatLayerRef.current = L.heatLayer(heatPoints, {
          radius: 35,
          blur: 20,
          maxZoom: 10,
          gradient: { 0.4: 'blue', 0.65: 'lime', 1: 'red' }
        }).addTo(heatMapInstanceRef.current);
      }
    } catch (err) {
      console.error(err);
      alert('Connection Failed. Ensure your backend is running.');
    } finally {
      setLoading(false);
    }
  };

  const getTextColor = (aqi) => {
    if (aqi > 200 || aqi <= 50) return 'white';
    return 'black';
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.header}>🛰️ Satellite AQI Monitor</h2>

      <div style={styles.controls}>
        <input
          type="text"
          placeholder="Latitude (e.g., 28.6139)"
          value={lat}
          onChange={(e) => setLat(e.target.value)}
          style={styles.input}
        />
        <input
          type="text"
          placeholder="Longitude (e.g., 77.2090)"
          value={lon}
          onChange={(e) => setLon(e.target.value)}
          style={styles.input}
        />
        <button
          onClick={fetchData}
          disabled={loading}
          style={styles.button}
        >
          {loading ? 'Loading...' : 'Get Satellite Data'}
        </button>
      </div>

      <div style={styles.tabsWrapper}>
        <div style={styles.tabs}>
          <div
            style={{
              ...styles.tab,
              ...(activeTab === 'current' ? styles.tabActive : {})
            }}
            onClick={() => setActiveTab('current')}
          >
            Current Status
          </div>
          <div
            style={{
              ...styles.tab,
              ...(activeTab === 'heatmap' ? styles.tabActive : {})
            }}
            onClick={() => setActiveTab('heatmap')}
          >
            Zone Heatmap
          </div>
          <div
            style={{
              ...styles.tab,
              ...(activeTab === 'forecast' ? styles.tabActive : {})
            }}
            onClick={() => setActiveTab('forecast')}
          >
            3-Day Forecast
          </div>
        </div>
      </div>

      {/* Current Tab */}
      {activeTab === 'current' && (
        <div style={styles.tabContent}>
          <div style={styles.gridSplit}>
            <div>
              <h3 style={styles.sectionTitle}>Real-time Air Quality</h3>
              <div
                style={{
                  ...styles.aqiCard,
                  backgroundColor: currentData.color,
                  color: getTextColor(currentData.aqi)
                }}
              >
                <div style={styles.aqiNumber}>{currentData.aqi}</div>
                <div style={styles.aqiStatus}>{currentData.label}</div>
              </div>

              <h4 style={styles.pollutantsTitle}>Pollutants (μg/m³)</h4>
              <div style={styles.pollutants}>
                <div style={styles.pBox}>
                  <strong>PM 2.5</strong>
                  <span>{currentData.components.pm2_5}</span>
                </div>
                <div style={styles.pBox}>
                  <strong>PM 10</strong>
                  <span>{currentData.components.pm10}</span>
                </div>
                <div style={styles.pBox}>
                  <strong>NO2</strong>
                  <span>{currentData.components.no2}</span>
                </div>
                <div style={styles.pBox}>
                  <strong>SO2</strong>
                  <span>{currentData.components.so2}</span>
                </div>
                <div style={styles.pBox}>
                  <strong>CO</strong>
                  <span>{currentData.components.co}</span>
                </div>
                <div style={styles.pBox}>
                  <strong>O3</strong>
                  <span>{currentData.components.o3}</span>
                </div>
              </div>
            </div>

            <div>
              <h3 style={styles.sectionTitle}>Location Map</h3>
              <div ref={mapRef} style={styles.map} />
            </div>
          </div>
        </div>
      )}

      {/* Heatmap Tab */}
      {activeTab === 'heatmap' && (
        <div style={styles.tabContent}>
          <h3 style={styles.sectionTitle}>Pollution Heatmap</h3>
          <p style={styles.description}>
            Visualizing pollution intensity zones based on satellite data.
          </p>
          <div ref={heatMapRef} style={styles.map} />
        </div>
      )}

      {/* Forecast Tab */}
      {activeTab === 'forecast' && (
        <div style={styles.tabContent}>
          <h3 style={styles.sectionTitle}>3-Day Forecast</h3>
          <p style={styles.description}>
            Predicted AQI based on dispersion models.
          </p>
          <div style={{ marginTop: '20px' }}>
            {forecastData.length === 0 ? (
              <div style={styles.emptyState}>
                Tap "Get Satellite Data" to load forecast
              </div>
            ) : (
              forecastData.map((day, index) => {
                const dateObj = new Date(day.dt * 1000);
                const dateStr = dateObj.toLocaleDateString('en-IN', {
                  weekday: 'short',
                  day: 'numeric',
                  month: 'short'
                });
                const textColor = getTextColor(day.aqi);

                return (
                  <div
                    key={index}
                    style={{
                      ...styles.forecastItem,
                      borderLeft: `5px solid ${day.aqi_color}`
                    }}
                  >
                    <div style={styles.fDate}>{dateStr}</div>
                    <div
                      style={{
                        ...styles.fBadge,
                        backgroundColor: day.aqi_color,
                        color: textColor
                      }}
                    >
                      AQI {day.aqi}
                    </div>
                    <div style={styles.fDetails}>
                      <span>{day.aqi_label}</span>
                      <br />
                      <small>PM2.5: {day.components.pm2_5}</small>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};

const styles = {
  container: {
    maxWidth: '1200px',
    margin: '0 auto',
    padding: '20px',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
    background: '#f4f7f6',
    color: '#333'
  },
  header: {
    textAlign: 'center',
    color: '#2c3e50',
    marginBottom: '20px',
    fontSize: '1.8rem'
  },
  controls: {
    background: 'white',
    padding: '20px',
    borderRadius: '12px',
    boxShadow: '0 4px 15px rgba(0,0,0,0.05)',
    display: 'flex',
    gap: '10px',
    marginBottom: '20px',
    flexWrap: 'wrap'
  },
  input: {
    padding: '12px 15px',
    border: '1px solid #ddd',
    borderRadius: '8px',
    flex: '1',
    minWidth: '200px',
    fontSize: '16px'
  },
  button: {
    padding: '12px 25px',
    background: '#007bff',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: '600',
    transition: 'background 0.2s',
    whiteSpace: 'nowrap'
  },
  tabsWrapper: {
    overflowX: 'auto',
    WebkitOverflowScrolling: 'touch',
    marginBottom: '-1px',
    paddingBottom: '5px'
  },
  tabs: {
    display: 'flex',
    minWidth: 'fit-content'
  },
  tab: {
    padding: '12px 20px',
    background: '#e0e0e0',
    cursor: 'pointer',
    borderRadius: '8px 8px 0 0',
    marginRight: '5px',
    fontWeight: '600',
    color: '#666',
    fontSize: '0.95rem',
    whiteSpace: 'nowrap'
  },
  tabActive: {
    background: 'white',
    color: '#007bff',
    borderTop: '3px solid #007bff'
  },
  tabContent: {
    background: 'white',
    padding: '25px',
    borderRadius: '0 8px 8px 8px',
    boxShadow: '0 4px 15px rgba(0,0,0,0.05)',
    animation: 'fadeIn 0.3s'
  },
  gridSplit: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '25px'
  },
  sectionTitle: {
    marginTop: '0',
    color: '#2c3e50'
  },
  aqiCard: {
    textAlign: 'center',
    padding: '25px',
    borderRadius: '12px',
    marginBottom: '20px'
  },
  aqiNumber: {
    fontSize: '3.5rem',
    fontWeight: '800',
    lineHeight: '1.1'
  },
  aqiStatus: {
    fontSize: '1.2rem',
    marginTop: '5px',
    fontWeight: '500',
    opacity: '0.9'
  },
  pollutantsTitle: {
    marginBottom: '10px',
    color: '#555'
  },
  pollutants: {
    display: 'grid',
    gridTemplateColumns: 'repeat(3, 1fr)',
    gap: '10px'
  },
  pBox: {
    background: '#f8f9fa',
    padding: '10px',
    borderRadius: '8px',
    textAlign: 'center',
    border: '1px solid #eee'
  },
  map: {
    height: '400px',
    width: '100%',
    borderRadius: '12px',
    border: '1px solid #ddd',
    zIndex: 1
  },
  description: {
    color: '#666',
    fontSize: '0.9rem',
    marginBottom: '15px'
  },
  forecastItem: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    background: '#fff',
    padding: '15px',
    marginBottom: '12px',
    borderRadius: '8px',
    border: '1px solid #eee',
    boxShadow: '0 2px 4px rgba(0,0,0,0.02)'
  },
  fDate: {
    width: '30%',
    fontWeight: '600',
    color: '#444'
  },
  fBadge: {
    padding: '5px 12px',
    borderRadius: '20px',
    fontWeight: 'bold',
    fontSize: '0.85rem',
    textAlign: 'center'
  },
  fDetails: {
    textAlign: 'right',
    fontSize: '0.85rem',
    color: '#777',
    width: '40%'
  },
  emptyState: {
    padding: '20px',
    textAlign: 'center',
    color: '#999',
    background: '#f9f9f9',
    borderRadius: '8px'
  }
};

// Media queries would need to be handled with CSS-in-JS library or CSS modules
// For now, you can add responsive styles using window resize listeners or a library like @emotion or styled-components

export default SatelliteAQIMonitor;
